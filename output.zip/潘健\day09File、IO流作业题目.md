# day09 File、IO流

## 题目1 File类型

### 整理File类常用方法

```
 1:构造方法  3个 
      File(String pathname) √
            根据  路径 的字符串  封装一个File对象
      File(String parent, String child) 
            根据 父路径和子路径 字符串  封装一个File对象
      File(File parent, String child) 
	        根据 父目录file对象和子路径字符串  封装成一个File对象
	  
	  绝对路径:  带盘符
	  相对路径:  不带盘符   跟项目相对的路径
	2:创建功能 
	  public boolean createNewFile() 创建新的文件
	  public boolean mkdir() 创建新的文件夹
	  public boolean mkdirs() 创建多级文件夹
	3:删除功能
	  public boolean delete() 删除比较暴力 谨慎使用 基本不用
	4:判断功能
	  public boolean isFile() 判断这个对象是否是文件   √
	  public boolean isDirectory() 判断这个对象是否是目录   √
	  public boolean exists() 判断这个对象对应的路径 是否真实存在
	5:获取功能
	  public String getName() 获取文件或文件夹名称   √
      public long length()  获取文件或文件夹大小 
	  public String getAbsolutePath() 获取绝对路径   √
	  public String getPath() 获取封装对象的 那个抽象路径
	  public long lastModified() 获取最后一次修改时间
	6:高级获取功能 
	  √ public String[] list() 获取目录下的所有文件或文件夹的名字以字符串数组形式存储
	  √ public File[] listFiles() 获取目录下 所有的文件或文件夹,它们以对象形式存储到数组中
	  

```

## 题目2 IO流

```
在程序中什么是编码，什么是解码?
    编码:将看得懂的变成看不懂的           
	      字符---数字      
    解码:将看不懂的变成看的懂得           
	      数字--字符       
请将字符串String中提供的编码解码方法整理出来:
    编码方法：
        new String(byte[] buffer) 将byte数组数据变成字符串 遵循默认的编码集。
        new String(byte[] buffer,0,len) 将byte数组一部分数据变成字符串 遵循默认的编码集。
        new String(byte[] buffer,String 指定编码集) 将byte数组数据变成字符串 按照指定的编码集。
    解码方法:
        字符串.getByte() 将字符串变成byte数组
        字符串.getByte(字符编码) 按照指定编码将字符串变成byte数组
```

```java
请整理出字节流的常用方法:
字节输入流老大 抽象类 
     InputStream  
          子类 FileInputStream  
              构造:
                   new FileInputStream(String/File 源文件);	
              方法:
                   int read() 每次读取一个字节，返回值就是读取到字节，如果读到文件末尾返回-1。
                   int read(byte[] buffer) 每次使用数组进行读取，将读取到的数据放到数组中,                        返回值读取到的真实的字节个数。
				                           如果读取个数-1说明读取到末尾。
				   
				   byte[] readAllBytes() 读取文件中所有的字节，封装到一个字节数组中(慎用 太占内存)  				   
                   void close()关闭通道释放资源 	
				   
	字节输出流老大 抽象类  
      OutputStream 
          子类 FileOutputStream  
              构造:
				 new FileOutputStream(String/File 源文件);
					字节输出流关联目标文件，目标文件不存会自动创建。存在会清空覆盖。
				 new FileOutputStream(String/File 源文件,true);	
					字节输出流关联目标文件，目标文件不存会自动创建。存在会追加。
              方法：
			       write(字节) 可以写一个字节出去
				   write(字节数组) 可以写一个字节数组出去
				   write(字节数组,起始索引,取几个) 可以写一个字节数组的一部分出去。
                   close()关闭管道释放资源  
```



## 题目3（综合扩展）

windows操作系统中可以复制文件夹,比如把D:\\from\\day11文件夹,复制到E:\\to\\day11文件夹下。但是java没有提供直接复制文件夹的方法.请编写程序定义两个文件夹路径,把其中一个文件夹中(包含内容)拷贝到另一个文件夹中。效果如下图：

![](img\05.png)

### 训练目标

能够使用递归调用定义方法,复制文件夹。

### 训练提示

1、该方法是否需要返回值?

2、如何复制单个文件，用什么流？

3、复制文件的功能实现后，文件夹怎么办？

### 参考方案

定义方法,复制文件夹,再调用方法传递两个文件夹File对象。

### 操作步骤  

1、定义复制文件到文件夹的方法copyFile2Dir

	1.1、创建文件字节输入流FileInputStream类的对象,绑定源文件
	    1.2、定义byte数组,保存每次读取到的字节的内容
	    1.3、定义int变量,保存每次读取到的字节数量
	   	1.4、根据目标文件夹和源文件,创建目标文件
	   	1.5、创建文件字节输出流FileOutputStream类的对象,绑定目标文件
	   	1.6、循环读(源文件)写(目标文件)
	   	1.7、关闭流释放资源
  2、定义复制文件夹到文件夹的方法copyDir2Dir

	2.1、在目标文件夹中创建源文件夹
	    2.2、获取源文件夹中的所有的文件和文件夹对应的File对象数组
	    2.3、判断,如果File对象数组是null或者没有内容,结束方法
	    2.4、遍历File对象数组
	    2.5、判断,如果当前File对象是文件,调用copyFile2Dir方法,完成文件复制
	    2.6、判断,如果当前File对象是文件夹,递归调用copyDir2Dir方法,完成文件夹复制
  3、创建File对象srcDir,代表源文件夹
  4、创建File对象destDir,代表目标文件夹(把源文件夹拷贝到目标文件夹中)
  5、调用copyDir2Dir方法,传递源文件夹和目标文件夹,完成文件夹的复制

### 参考答案



```
 public static void main(String[] args) throws IOException {
     File file = new File("D:\\ben\\");
     File newFile = new File("D:\\newben\\");
     copy(file , newFile);
 }
public static void copy(File oldDir, File newDir) throws IOException {
    File[] files = oldDir.listFiles();
    for (File file : files) {
      if(file.isDirectory()){
          File dir = new File(newDir+"\\"+file.getName());
          dir.mkdir();
          copy(file, dir);
      }else{
          File newFile = new File(newDir +"\\"+ file.getName());
          newFile.createNewFile();
          FileInputStream fis = new FileInputStream(oldDir+"\\" +file.getName());
          FileOutputStream fos = new FileOutputStream(newFile);
          byte[] bytes= new byte[1024*8];
          int len ;
          while ((len=fis.read(bytes))!=-1){
              fos.write(bytes,0,len);
          }
          fos.close();
          fis.close();
      }
    }

}
```
