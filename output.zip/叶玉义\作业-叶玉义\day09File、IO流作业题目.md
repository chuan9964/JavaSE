# day09 File、IO流

## 题目1 File类型

### 整理File类常用方法

```
1:构造方法  3个 
public File(String pathname) 根据文件路径创建文件对象
public File(String parent,String child) 根据父路径和子路径名字创建文件对象。
public File(File parent,String child) 根据父路径对应文件对象和子路径名字创建文件对象。
	  绝对路径: 带盘符的路径，是绝对路径。 
	  相对路径: 不带盘符的路径，是相对路径。
2:创建功能 
createNewFile() 创建一个新的文件
mkdir() 只能创建单级文件夹
mkdirs() 才能创建多级文件夹
3:删除功能
delete() ,删除文件或目录（当前目录为空）
4:判断功能
exists() 判断当前文件对象，对应的文件路径是否存在，存在true。
isFile() 判断当前文件对象指代的是否是文件，是文件返回true，反之。
isDirectory() 判断当前文件对象指代的是否是文件夹，文件夹返回rue，反之。
5:获取功能
getName() 获取文件的名称
length() 获取文件的大小，返回字节个数
lastModified() 获取文件的最后修改时间
getPath() 获取创建文件封装的路径
getAbsolutePath() 获取绝对路径
6:高级获取功能 
list() 获取当前目录下所有的"一级文件名称"到一个字符串数组中去返回。
listFiles() 获取当前目录下所有的"一级文件对象"到一个文件对象数组中去返回（重点）
```

## 题目2 IO流

```
在程序中什么是编码，什么是解码?
    编码:把字符串按照指定的字符集转换为字节数组
    解码:把字节数组按照指定的字符集转换为字符串
请将字符串String中提供的编码解码方法整理出来:
    编码方法：
getBytes() 使用默认字符集，将该String编码为一系列字节，将结果存储到新的字节数组中
getBytes(String charsetName) 使用指定字符集，将该String编码为一系列字节，将结果存储到新的字节数组中
    解码方法:
String(byte[] bytes) 通过默认字符集解码指定的字节数组来构造新的String
String(byte[] bytes, String charsetName) 通过指定的字符集解码指定的字节数组来构造新的String    
```

```java
请整理出字节流的常用方法:
字节输入流老大 抽象类 
     InputStream  
          子类 FileInputStream  
              构造:
            FileInputStream(File file) 创建字节输入流管道与源文件接通     	
              方法:
            read()	每次读取一个字节返回，如果发现没有数据可读会返回-1.    
				   
	字节输出流老大 抽象类  
      OutputStream 
          子类 FileOutputStream  
              构造:
			FileInputStream(File file) 创建字节输入流管道与源文件接通	
              方法：
			read(byte[] buffer) 每次用一个字节数组去读取数据，返回字节数组读取了多少个字节，如果发现没有数据可读会返回-1.   
```



## 题目3（综合扩展）

windows操作系统中可以复制文件夹,比如把D:\\from\\day11文件夹,复制到E:\\to\\day11文件夹下。但是java没有提供直接复制文件夹的方法.请编写程序定义两个文件夹路径,把其中一个文件夹中(包含内容)拷贝到另一个文件夹中。效果如下图：

![](img\05.png)

### 训练目标

能够使用递归调用定义方法,复制文件夹。

### 训练提示

1、该方法是否需要返回值?

2、如何复制单个文件，用什么流？

3、复制文件的功能实现后，文件夹怎么办？

### 参考方案

定义方法,复制文件夹,再调用方法传递两个文件夹File对象。

### 操作步骤  

1、定义复制文件到文件夹的方法copyFile2Dir

	1.1、创建文件字节输入流FileInputStream类的对象,绑定源文件
	    1.2、定义byte数组,保存每次读取到的字节的内容
	    1.3、定义int变量,保存每次读取到的字节数量
	   	1.4、根据目标文件夹和源文件,创建目标文件
	   	1.5、创建文件字节输出流FileOutputStream类的对象,绑定目标文件
	   	1.6、循环读(源文件)写(目标文件)
	   	1.7、关闭流释放资源
  2、定义复制文件夹到文件夹的方法copyDir2Dir

	2.1、在目标文件夹中创建源文件夹
	    2.2、获取源文件夹中的所有的文件和文件夹对应的File对象数组
	    2.3、判断,如果File对象数组是null或者没有内容,结束方法
	    2.4、遍历File对象数组
	    2.5、判断,如果当前File对象是文件,调用copyFile2Dir方法,完成文件复制
	    2.6、判断,如果当前File对象是文件夹,递归调用copyDir2Dir方法,完成文件夹复制
  3、创建File对象srcDir,代表源文件夹
  4、创建File对象destDir,代表目标文件夹(把源文件夹拷贝到目标文件夹中)
  5、调用copyDir2Dir方法,传递源文件夹和目标文件夹,完成文件夹的复制

### 参考答案

```java
import java.io.*;
import java.util.Scanner;

public class Test05 {
 public static void main(String[] args) throws IOException {
        File sirDir = new File("D:\\from\\day11");
        File destDir = new File("E:\\to");
        copyDir2Dir(sirDir,destDir);
    }

    public static void copyFile2Dir(File file,File dir) throws IOException {//源文件、目标文件
        FileInputStream in = new FileInputStream(file);
        byte[] bytes = new byte[1024*10];
        int len;
        //根据目标文件夹和源文件,创建目标文件
        File destFile = new File(dir,file.getName());
        FileOutputStream out = new FileOutputStream(destFile);
            while((len=in.read(bytes))!=-1){
                out.write(bytes,0,len);
            }
        out.close();
        in.close();
    }

    public static void copyDir2Dir(File srcDir,File destDir) throws IOException {//源文件夹、目标文件夹
        File newDir = new File(destDir,sirDir.getName());
        File[] files = srcDir.listFiles();
        if(files==null || files.length==0){
            return;
        }
        for (File file : files) {
           if(file.isFile()){
               copyFile2Dir(file,newDir);
           }
           if (file.isDirectory()){
               copyDir2Dir(file,newDir);
               newDir.mkdirs();
           }
        }
    }
}
```

