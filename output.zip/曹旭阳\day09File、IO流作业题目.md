# day09 File、IO流

## 题目1 File类型

### 整理File类常用方法

```
1:构造方法  3个 
     
	  
	  绝对路径:  
	  相对路径:  
2:创建功能 
	 
3:删除功能
	 
4:判断功能
	
5:获取功能
	 
6:高级获取功能 
	  

```

## 题目2 IO流

```
在程序中什么是编码，什么是解码?
    编码:
    解码:
请将字符串String中提供的编码解码方法整理出来:
    编码方法：
    
    解码方法:
```

```java
请整理出字节流的常用方法:
字节输入流老大 抽象类 
     InputStream  
          子类 FileInputStream  
              构造:
                   	
              方法:
                  
				   
	字节输出流老大 抽象类  
      OutputStream 
          子类 FileOutputStream  
              构造:
				
              方法：
			      
```



## 题目3（综合扩展）

windows操作系统中可以复制文件夹,比如把D:\\from\\day11文件夹,复制到E:\\to\\day11文件夹下。但是java没有提供直接复制文件夹的方法.请编写程序定义两个文件夹路径,把其中一个文件夹中(包含内容)拷贝到另一个文件夹中。效果如下图：

![](img\05.png)

### 训练目标

能够使用递归调用定义方法,复制文件夹。

### 训练提示

1、该方法是否需要返回值?

2、如何复制单个文件，用什么流？

3、复制文件的功能实现后，文件夹怎么办？

### 参考方案

定义方法,复制文件夹,再调用方法传递两个文件夹File对象。

### 操作步骤  

1、定义复制文件到文件夹的方法copyFile2Dir

	1.1、创建文件字节输入流FileInputStream类的对象,绑定源文件
	    1.2、定义byte数组,保存每次读取到的字节的内容
	    1.3、定义int变量,保存每次读取到的字节数量
	   	1.4、根据目标文件夹和源文件,创建目标文件
	   	1.5、创建文件字节输出流FileOutputStream类的对象,绑定目标文件
	   	1.6、循环读(源文件)写(目标文件)
	   	1.7、关闭流释放资源
  2、定义复制文件夹到文件夹的方法copyDir2Dir

	2.1、在目标文件夹中创建源文件夹
	    2.2、获取源文件夹中的所有的文件和文件夹对应的File对象数组
	    2.3、判断,如果File对象数组是null或者没有内容,结束方法
	    2.4、遍历File对象数组
	    2.5、判断,如果当前File对象是文件,调用copyFile2Dir方法,完成文件复制
	    2.6、判断,如果当前File对象是文件夹,递归调用copyDir2Dir方法,完成文件夹复制
  3、创建File对象srcDir,代表源文件夹
  4、创建File对象destDir,代表目标文件夹(把源文件夹拷贝到目标文件夹中)
  5、调用copyDir2Dir方法,传递源文件夹和目标文件夹,完成文件夹的复制

### 参考答案

```java
package com.itheima.homework;

import java.io.*;

/**
 * @Author:曹旭阳
 */
public class work01 {
    /*
        需求：将一整个文件夹全部复制到目标文件夹下
        分析
        方法参数 源文件 目标地址
        具体步骤
        判断当前文件对象是不是目录
            是目录就复制
                是目录就在目标位置创建同名目录 将目标地址加该文件夹名
                当前目录是否为空
                    为空 复制完成退出
                    不为空 复制该目录
                        内容是文件就复制
                        内容是目录重复上述步骤
            不是目录就返回

     */
    public static void main(String[] args) throws IOException {
        //文件复制
//        File file = new File("E:\\HeiMaJava\\就业班\\day08");
//        copyOf(file,"E:\\HeiMaJava\\");
        //文件删除
        File file = new File("E:\\HeiMaJava\\就业班\\day09\\04_家庭作业Homework");
        delete(file);
    }

    public static void copyOf(File file, String path) throws IOException {
        //不是目录就返回
        if (!(file.isDirectory()))
            return;
        //是目录
        //创建文件夹
        path = path + file.getName() + "\\";
        new File(path).mkdir();

        //复制当前目录
        File[] files = file.listFiles();
        //文件内容为空 退出
        if(files == null || files.length == 0)
            return;
        //复制内容
        for (File file1 : files) {
            //是文件就复制
            if (file1.isFile()) {
                FileInputStream fis = new FileInputStream(file1);
                FileOutputStream fos = new FileOutputStream(path + file1.getName());
                byte[] bytes = new byte[1024 * 8];
                int count;
                while ((count = fis.read(bytes)) != -1) {
                    fos.write(bytes, 0, count);
                }
                //复制完成，关闭流
                fos.close();
                fis.close();
            } else {
                //不是文件重复上述步骤
                copyOf(file1, path);
            }
        }

    }

    public static void delete(File file) {
        File[] files = file.listFiles();
        if (files == null)
            return;
        //当前文件不为空，先删除里面内容
        if (files.length != 0){
            for (File file1 : files) {
                if (file1.isFile()){
                    file1.delete();
                }else {
                    delete(file1);
                }
            }
        }
        //再删除自己
        if (file.listFiles().length == 0)
            file.delete();
    }
}



```

