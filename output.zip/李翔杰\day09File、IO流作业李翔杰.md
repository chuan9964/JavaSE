# day09 File、IO流

## 题目1 File类型

### 整理File类常用方法

```java
1:构造方法  3个 
public File(String pathname)  根据文件路径创建文件对象
public File(String parent,String child)  根据父路径和子路径名字创建文件对象
public File(File parent, String child) 根据父路径对应文件对象和子路径名字创建
文件对象
     
	  
	  绝对路径:  带盘符
	  相对路径:  不带盘符
2:创建功能
    public boolean createNewFile()  创建一个新的空的文件夹
    public boolean mkdir()  只能创建一级文件夹
    public boolean mkdirs()  可以创建多级文件夹
	 
3:删除功能
    public boolean delete() 删除文件 空文件夹
	 
4:判断功能
    public boolean exists() 判断当前文件对象，对应的文件路径是否存在，存在返回true
    public boolean isFile() 判断当前文件对象指代的是否是文件，是文件返回true
    public boolean isDirectory() 判断当前文件对象指代的是否是文件夹，是文件夹返回true
	
5:获取功能
    public String getName() 获取文件的名称（包含后缀）
    public long length() 获取文件的大小，返回字节个数
    public long lastModified() 获取文件的最后修改时间
    public String getPath() 获取创建文件对象时，使用的路径
    public String getAbsolutePath() 获取绝对路径
	 
6:高级获取功能 
    public String[] list() 获取目录下的所有文件夹或文件夹名字以字符串数组形式存储
    public File[] listFiles() 获取目录下 所有的文件或文件夹，他们以对象形式存储到数组中
	  

```

## 题目2 IO流

```java
在程序中什么是编码，什么是解码?
    编码:将看得懂得变成看不懂的
    	字符---数字
    解码:将看不懂的变成看得懂得
    	数字---字符
请将字符串String中提供的编码解码方法整理出来:
    编码方法：
    	new String(byte[] buffer) 将byte数组数据变成字符串 遵循默认的编码集
        new String(byte[] buffer,0,len) 将byte数组一部分数据变成字符串 遵循默认的
        编码集
        new String(byte[] buffer,String 指定编码集)将byte数组变成字符串 按照指定的
        编码集
    
    解码方法:
		字符串.getByte() 将字符串变成byte数组
        字符串.getByte(字符编码) 按照指定编码将字符串变成byte数组
```

```java
请整理出字节流的常用方法:
字节输入流老大 抽象类 
     InputStream  
          子类 FileInputStream  
              构造:
					new FileInputStream(String/File);
                   	
              方法:
					int read() 每次读取一个字节，读到末尾返回-1.
                    int read(byte[] buffer) 每次使用数组进行读取，将读取到的数据放到数组中  返回值是读取到真实的字节个数  如果读取个数-1说明读到末尾。
                    byte[] readAllBytes() 读取文件中所有字节，封装到一个字节数组中
                    void close() 关闭通道
                  
				   
	字节输出流老大 抽象类  
      OutputStream 
          子类 FileOutputStream  
              构造:
				new FileOutputStream(String/File);
				字节输出流关联目标文件，目标文件不存会自动创建。存在会清空覆盖。
                new FileOutputStream(String/File, true);
				字节输出流关联目标文件，目标文件不存在会自动创建。存在会追加
				
              方法：
                 write(字节) 可以写一个字节出去
                 write(字节数组)  可以写一个字节数组出去
                 write(字节数组，起始索引，取得个数) 可以写一个字节数组的一部分出去
                 close() 关闭管道
			      
```



## 题目3（综合扩展）

windows操作系统中可以复制文件夹,比如把D:\\from\\day11文件夹,复制到E:\\to\\day11文件夹下。但是java没有提供直接复制文件夹的方法.请编写程序定义两个文件夹路径,把其中一个文件夹中(包含内容)拷贝到另一个文件夹中。效果如下图：

![](img\05.png)

### 训练目标

能够使用递归调用定义方法,复制文件夹。

### 训练提示

1、该方法是否需要返回值?

2、如何复制单个文件，用什么流？

3、复制文件的功能实现后，文件夹怎么办？

### 参考方案

定义方法,复制文件夹,再调用方法传递两个文件夹File对象。

### 操作步骤  

1、定义复制文件到文件夹的方法copyFile2Dir

	1.1、创建文件字节输入流FileInputStream类的对象,绑定源文件
	    1.2、定义byte数组,保存每次读取到的字节的内容
	    1.3、定义int变量,保存每次读取到的字节数量
	   	1.4、根据目标文件夹和源文件,创建目标文件
	   	1.5、创建文件字节输出流FileOutputStream类的对象,绑定目标文件
	   	1.6、循环读(源文件)写(目标文件)
	   	1.7、关闭流释放资源
  2、定义复制文件夹到文件夹的方法copyDir2Dir

	2.1、在目标文件夹中创建源文件夹
	    2.2、获取源文件夹中的所有的文件和文件夹对应的File对象数组
	    2.3、判断,如果File对象数组是null或者没有内容,结束方法
	    2.4、遍历File对象数组
	    2.5、判断,如果当前File对象是文件,调用copyFile2Dir方法,完成文件复制
	    2.6、判断,如果当前File对象是文件夹,递归调用copyDir2Dir方法,完成文件夹复制
  3、创建File对象srcDir,代表源文件夹
  4、创建File对象destDir,代表目标文件夹(把源文件夹拷贝到目标文件夹中)
  5、调用copyDir2Dir方法,传递源文件夹和目标文件夹,完成文件夹的复制

### 参考答案

```java
import java.io.File;
import java.util.Scanner;

public class Test03 {
    public static void copyFile2Dir(File file,File dir) throws IOException{
        InputStream is = new FileInputStream(file);
        byte[] bs = new byte[1024*10];
        int len = 0;
        File destFile = new File(dir,file.getName());
        OutputStream os = new FileOutputStream(destFile);
        while ((len = is.read(bs))!=-1) {
            os.write(bs,0,len);
        }
        is.close();
        os.close();
    }
    public static void copyDir2Dir(File srcDir,File destDir) throws IOException{
        File newDir = new File(destDir,srcDir.getName());
        if(!newDir.exists()){
            newDir.mkdirs();
        }
        File[] files = srcDir.listFiles();
        if(files==null||files.length==0) {
            return;
        }
        for (File file : files) {
            if(file.isFile()) {
                copyFile2Dir(file,newDir);
            }else {
                copyDir2Dir(file,newDir);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        File srcDir = new File("C:\\视屏\\ddg");
        File destDir = new File("C:\\视屏\\xxg");
        copyDir2Dir(srcDir,destDir);
        System.out.println("复制完毕");
    }
}

```

